//PowerUps
var energyPower;

var Energy = {
    initialize  :   function(){
        let energyPowerInterval = game.rnd.integerInRange(10, 30);
        energyPowerTimer = game.time.create(false);
        energyPowerTimer.loop(energyPowerInterval*1000, Energy.newEnergy);
        energyPowerTimer.start();

    },
    newEnergy   :   function(){
        let energyPowerX = game.rnd.integerInRange(20, game.world.width-20);
        energyPower = game.add.sprite(energyPowerX, 0, "life");      
        energyPower.scale.setTo(20/energyPower.width, 20/energyPower.height);
        game.physics.enable(energyPower, Phaser.Physics.ARCADE);
        energyPower.enableBody = true;
        //life.anchor.set(0.5);
        energyPower.body.velocity.set(0, 200);},
    delete      :   function(){
        energyPower.kill();

    },
    setnull     :   function(){
        energyPower.kill();
        energyPowerTimer.stop();

    }
}

var coins;
var Coins = {
    coinInfo : {
        width: 15,
        height: 15,
        offset: {
            top: -60,
            left: 20
        },
        padding: 0
    },
    initialize : function(){
        if(coins){
            Coins.delete();
        }
        coins = game.add.group();
        game.physics.enable(coins, Phaser.Physics.ARCADE);
        coins.enableBody = true;

        coinsTimer = game.time.create(false);
        coinsTimer.loop(500, Coins.newCoin);
        coinsTimer.start();
    },
    newCoin : function(){//Creates new coin and drops it
        //First checks if coin object leave the screen and destroy it
        coins.forEach(function(coin)
        {
            if(coin.body.y >= game.world.height)
            {   
                coin.destroy();  
            }
        }); // And here the coin is created
        coinCost = level;
        let will = game.rnd.integerInRange(0,1);
        if(will){
            //let coinX = (c*(Coins.coinInfo.width+Coins.coinInfo.padding))+Coins.coinInfo.offset.left;
            //let coinY = (r*(Coins.coinInfo.height+Coins.coinInfo.padding))+Coins.coinInfo.offset.top;
            let coinX = game.rnd.integerInRange(10,game.world.width-10);
            let coinY = -60;
            
            coin = coins.create(coinX, coinY, "coin");  
            coin.scale.setTo(15/coin.width, 15/coin.height);
            coin.anchor.set(0.5, 0.5);
            coin.body.bounce.set(1);
            coin.body.velocity.set(0, 200+level*level);
        }
    },
    delete  :  function(){
        //aliens.destroy();
        coinsTimer.stop();
    }
}
